#!/usr/bin/env bash

# apt-get update
apt-get -y install openjdk-21-jdk ant
# apt-get -y install xvfb libxrender1 libxtst6 libxi6 # for things that need the video driver, like 08-image-mosaic
