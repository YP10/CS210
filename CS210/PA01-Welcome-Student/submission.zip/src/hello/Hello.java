//
// Copyright (c) 2025 Tim Richards. All rights reserved.
//
package hello;

public class Hello {

  public static String helloString() {
    return "Hello, CICS 210 Data Structures World!";
  }

  public static void main(String[] args) {
    System.out.println(helloString());
  }
}